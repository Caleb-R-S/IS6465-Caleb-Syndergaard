-- Run after setup-database.sql. Rebuild students to add the account link while
-- preserving the original student IDs used by tutoring_requests.
PRAGMA foreign_keys = OFF;

CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('Student', 'Tutor', 'Administrator')),
    status TEXT NOT NULL DEFAULT 'Active' CHECK(status IN ('Active', 'Inactive')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE students RENAME TO students_lab6;
CREATE TABLE students (
    student_id INTEGER PRIMARY KEY,
    student_name TEXT NOT NULL,
    student_email TEXT NOT NULL UNIQUE,
    user_id INTEGER UNIQUE,
    FOREIGN KEY(user_id) REFERENCES users(user_id)
);
INSERT INTO students (student_id, student_name, student_email)
SELECT student_id, student_name, student_email FROM students_lab6;
DROP TABLE students_lab6;
CREATE UNIQUE INDEX IF NOT EXISTS idx_students_user_id ON students(user_id);
PRAGMA foreign_keys = ON;
